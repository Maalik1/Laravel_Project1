

@extends('layouts.app')
@section('content')



  

    <table class="table table-bordered">
    <tr>
<th>
ID
</th>
<th>
    Title
</th>
<th>
    Edit
</th>
<th>
    Delete
</th>

    </tr>


    @foreach($students as $student)
              <tr>

              <td>  {{ $student->id  }} </td>
               <td> {{ $student->name }}   </td>   

                <td>
                <a href="{{ route('edit',$student->id)}}">
                    <button class="btn btn-success">Edit</button>
                    </a>
                </td>
                <td>
                <a href="{{ route('delete',$student->id)}}">
                    <button class="btn btn-danger">Delete</button>
                </a>
                </td>



         
              </tr>

             @endforeach





    </table>

</div>






@endsection