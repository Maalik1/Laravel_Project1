<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});

*/

Route::get('/', 'App\Http\Controllers\postController@welcome')->name('home');
Route::get('/welcome', 'App\Http\Controllers\postController@welcome')->name('welcome');
Route::get('/student','App\Http\Controllers\postController@student')->name('student');
Route::get('/education','App\Http\Controllers\postController@education')->name('education');
Route::get('/savestudent','App\Http\Controllers\postController@savestudent')->name('savestudent');
Route::get('/saveeducation','App\Http\Controllers\postController@saveeducation')->name('saveeducation');
Route::get('/finish','App\Http\Controllers\postController@finish')->name('finish');
Route::get('/edit/{id}','App\Http\Controllers\postController@edit')->name('edit');
Route::get('/delete/{id}','App\Http\Controllers\postController@delete')->name('delete');
Route::post('/update/{id}','App\Http\Controllers\postController@update')->name('update');
Route::post('/updateeducation/{id}','App\Http\Controllers\postController@updateeducation')->name('updateeducation');
Route::post('/updateeducationview/{id}','App\Http\Controllers\postController@updateeducationview')->name('updateeducationview');