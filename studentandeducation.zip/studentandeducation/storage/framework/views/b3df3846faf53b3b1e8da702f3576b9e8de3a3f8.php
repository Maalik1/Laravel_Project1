<?php $__env->startSection('content'); ?>



  

    <table class="table table-bordered">
    <tr>
<th>
ID
</th>
<th>
    Title
</th>
<th>
    Edit
</th>
<th>
    Delete
</th>

    </tr>


    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

              <td>  <?php echo e($student->id); ?> </td>
               <td> <?php echo e($student->name); ?>   </td>   

                <td>
                <a href="<?php echo e(route('edit',$student->id)); ?>">
                    <button class="btn btn-success">Edit</button>
                    </a>
                </td>
                <td>
                <a href="<?php echo e(route('delete',$student->id)); ?>">
                    <button class="btn btn-danger">Delete</button>
                </a>
                </td>



         
              </tr>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





    </table>

</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Students registration Project\Part 3\studentandeducation\resources\views/welcome.blade.php ENDPATH**/ ?>