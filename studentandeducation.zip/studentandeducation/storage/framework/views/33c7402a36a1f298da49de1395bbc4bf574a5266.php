
Form Submitted
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Students registration Project\Part 2\studentandeducation\resources\views/finish.blade.php ENDPATH**/ ?>