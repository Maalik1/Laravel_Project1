<?php

namespace App\Http\Controllers;

use App\Models\education;
use Illuminate\Http\Request;

//use App\Models\post;
use App\Models\student;

class postController extends Controller
{



    
    public function welcome(){
        
        $students=student::orderby('id','asc')->get();
      
        return view('welcome' , compact('students'));
     }
 

   /*  public function welcome(){


        return view('welcome');
    }
*/

    public function student(){


        return view('student');
    }

    public function education(){


        return view('education');
    }


    public function savestudent(Request $request){
            
        $student=new student;
        $student->name =$request->name;
        $student->fathername =$request->fathername;
        $student->age =$request->age;
        $student->address =$request->address;
        $student->email =$request->email;
        $student->password =$request->password;
        $student->save();
        return redirect(route('education') ) ->with('success', 'Your Content is posted successfully');
       // return redirect()->back();


    }


  
    public function saveeducation(Request $request){
            
        $education=new education;
        $education->matriculation =$request->matriculation;
        $education->intermediate =$request->intermediate;
        $education->bachelor =$request->bachelor;
    
        
        $education->save();
        return redirect(route('finish') ) ->with('success', 'Your Content is posted successfully');
       // return redirect()->back();


    }






    public function edit($id){

    
 
         $students = student::find($id);
        
         return view('edit',compact('students'));
 
         }




         public function update(Request $request, $id) //update student
         {
             
                  $student=student::find($id);
                  $student->name =$request->name;
                  $student->fathername =$request->fathername;
                  $student->age =$request->age;
                  $student->address =$request->address;
                  $student->email =$request->email;
                  $student->password =$request->password;
                  $student->save();

                  $education = education::find($id);
        
         return view('updateeducationview',compact('education'));
                  //return redirect(route('updateeducationview' , $id) );
 
         }

         public function updateeducation(Request $request, $id) //update 
         {

             
            $education=education::find($id);
            $education->matriculation =$request->matriculation;
            $education->intermediate =$request->intermediate;
            $education->bachelor =$request->bachelor;
            $education->save();
            return redirect(route('finish') ) ->with('success', 'Your Content is posted successfully');
         
 
         }

         public function updateeducationview($id){

    
 
            $education = education::find($id);
           
            return view('updateeducationview',compact('education'));
    
            }


 
         public function delete($id){
            // return $id;
            $student=student::find($id);
           // return $post;
           $student->delete();
           $education=education::find($id);
           $education->delete();
           return redirect()-> back() ->with('success', 'Your Content is Deleted successfully');
         }



    public function finish(){


        return view('finish');
    }


}


